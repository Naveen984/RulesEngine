﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RulesEngine.Classes
{
    public class RulesDataStream
    {
        public string Signal { get; set; }
        public object Value { get; set; }
        public string Value_Type { get; set; }
    }
}
