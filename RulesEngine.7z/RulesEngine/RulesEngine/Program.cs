﻿using System;
using System.Collections.Generic;
using System.IO;
using RulesEngine.Classes;
using RulesEngine.User_Interface;

namespace RulesEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Rules Engine Starts");
            Console.WriteLine("If you want to run the rule engine on raw data. Please type Y or N?");
            char userInput = Convert.ToChar(Console.ReadLine());
            string GetDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            IRulesEngine ruleEngRdr = RulesEngineReader.GetInstance(GetDirectory);
            List<string> ruleEngineProcsdData = new List<string>();
            if (Equals(char.ToUpper(userInput), 'Y'))
            {
                Console.WriteLine("Please keep your rule engine data stream file at " + GetDirectory + " and press any key to continue.");
                Console.ReadLine();
                string[] filePath = Directory.GetFiles(GetDirectory, "*.json");
                string extFilePath = Utility.CheckForExtFile(GetDirectory, filePath);
                Console.WriteLine("Getting rules from file " + extFilePath + ".");
                ruleEngineProcsdData = ruleEngRdr.LoadJsonStreamInRuleEngine(extFilePath);
            }
            else
            {
                Console.WriteLine("Getting rules from file raw_data.json.");
                ruleEngineProcsdData = ruleEngRdr.LoadJsonStreamInRuleEngine(@"\raw_data.json");
            }

            IRulesEngineWriter ruleEngRes = RulesEngineWriter.GetInstance(GetDirectory + @"\VoilatedRules.txt");
            ruleEngRes.SaveVoilatedRules(ruleEngineProcsdData);
            Console.WriteLine("Rule engine voilated result saved to " + GetDirectory + @"\VoilatedRules.txt");
            Console.ReadLine();
        }
    }
}