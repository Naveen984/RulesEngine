﻿using System.Collections.Generic;
using RulesEngine.Classes;

namespace RulesEngine.User_Interface
{
    interface IRulesEngine
    {
        List<string> LoadJsonStreamInRuleEngine(string dataFileName);
        List<string> ProcessJsonStreamInRuleEngine(List<RulesDataStream> ruleDataStreamList);
    }
}