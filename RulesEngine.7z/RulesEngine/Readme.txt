1. Briefly describe the conceptual approach you chose! What are the trade-offs?
Ans: I focused on the input file provided by the user in json format and as per the data provided. The user define their own rules to get the voilated signals and save the same in text file at application path. I tried my best not to create any tradeoffs for this application.

2. What's the runtime performance? What is the complexity? Where are the bottlenecks?
Ans: Memory Usage: 25-26 KB, Time taken to complete task including user defined rule (default file): 30 Secs.
For me, the major bottleneck for this app was: Unable to test the same on multiple OS becuase I have tested only on Windows system.

3. If you had more time, what improvements would you make, and in what order of priority?
Ans: If I had more time then I would have worked on given below points to improve:
a. Make app Less time consumption than current time consumption or would have refactored my code in more better way to make it run more faster.
b. Would have given the option to save output in database
c. Would have tested the application with hugh no. of data to make it more efficient.